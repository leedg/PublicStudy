#pragma once

// NetworkEvent 다중 구독자 이벤트 버스.
//
// Usage:
//   // Subscribe
//   auto ch = std::make_shared<NetworkEventBus::EventChannel>(
//       Concurrency::ExecutionQueueOptions<NetworkBusEventData>{.mCapacity = 128});
//   auto handle = NetworkEventBus::Instance().Subscribe(NetworkEvent::Connected, ch);
//
//   // Consume (separate thread)
//   NetworkBusEventData evt;
//   while (ch->Receive(evt, 100)) { /* handle */ }
//
//   // Unsubscribe
//   NetworkEventBus::Instance().Unsubscribe(handle);

#include "../../Concurrency/Channel.h"
#include "NetworkEngine.h"
#include <atomic>
#include <memory>
#include <shared_mutex>
#include <unordered_map>
#include <vector>

namespace Network::Core
{

// =============================================================================
// 버스용 복사 가능 이벤트 데이터.
// NetworkEventData는 unique_ptr 소유로 move-only.
// NetworkBusEventData는 vector<uint8_t> 사용으로 복사 가능하며
// 다수의 구독자 채널에 전달 가능.
// =============================================================================

struct NetworkBusEventData
{
	NetworkEvent         eventType{};      // 이벤트 종류
	ConnectionId         connectionId{0};  // 관련 세션 ID
	size_t               dataSize{0};      // data 벡터의 유효 바이트 수
	OSError              errorCode{0};     // OS 에러 코드 (없으면 0)
	Timestamp            timestamp{0};     // 이벤트 발생 시각
	std::vector<uint8_t> data;             // 페이로드 복사 (데이터 없으면 empty — 다중 구독자에 복사 전달)
};

// =============================================================================
// NetworkEventBus — 스레드 안전 싱글턴 이벤트 버스.
// Publish()는 BaseNetworkEngine::FireEvent()에서 호출.
// 구독자는 채널을 소유하고 임의 스레드에서 드레인 가능.
// =============================================================================

class NetworkEventBus
{
  public:
	using EventChannel      = Network::Concurrency::Channel<NetworkBusEventData>;
	using SubscriberHandle  = uint64_t;

	static NetworkEventBus &Instance();

	// eventType을 구독 중인 모든 채널에 이벤트 발행.
	// 만료된 weak_ptr 구독자는 다음 Publish 시 지연 제거.
	void Publish(NetworkEvent type, const NetworkBusEventData &data);

	// eventType 구독. 나중에 구독 해제할 핸들 반환.
	// 구독이 이벤트를 수신하는 동안 channel은 살아있어야 함.
	SubscriberHandle Subscribe(NetworkEvent type, std::shared_ptr<EventChannel> channel);

	// 핸들로 구독 취소.
	void Unsubscribe(SubscriberHandle handle);

  private:
	NetworkEventBus() = default;

	struct Subscription
	{
		SubscriberHandle            handle;   // Unsubscribe() 에 전달할 고유 핸들
		std::weak_ptr<EventChannel> channel;  // 구독자 채널 — 만료 시 다음 Publish에서 지연 제거
	};

	// ─── 내부 상태 ───────────────────────────────────────────────────────────
	std::unordered_map<uint8_t, std::vector<Subscription>> mSubscribers;  // NetworkEvent 키별 구독자 리스트
	mutable std::shared_mutex                              mMutex;        // mSubscribers 읽기(shared)·쓰기(unique) 보호
	std::atomic<SubscriberHandle>                          mNextHandle{1}; // 단조 증가 핸들 생성기 (relaxed)
};

} // namespace Network::Core
