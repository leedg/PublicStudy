CREATE TABLE IF NOT EXISTS T_Users (
    user_id    BIGINT NOT NULL PRIMARY KEY,
    username   VARCHAR(255) NOT NULL,
    created_at DATETIME NOT NULL
);
